#include <stdio.h>

int seq(int n) {
	if (n == 1)
		return 3;
	else if (n == 2)
		return 4;
	else
		return 0.5*seq3(n-1) + 2*seq3(n-2);
}

int seq3(int n) {
	static int wywolanie = 0;
	
	wywolanie++;
	
	printf("seq%u(%u) = %u\n", wywolanie, n, seq(n));
	
	if (n == 1)
		return 3;
	if (n == 2)
		return 4;
	return 0.5*seq3(n-1) + 2*seq3(n-2);
}

int main() {
	printf("SequenceTree.c\n\n");
	
	int n = 4;
	printf("seq(%u) = %u\n", n, seq3(n));
	return 0;
}
