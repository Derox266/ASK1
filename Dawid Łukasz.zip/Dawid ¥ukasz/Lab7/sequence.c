#include <stdio.h>

/*
r0  r1  r2
|---|---|       .
1   2   3   4   5   6      indeksy
3   4   8   12  22  35     warto�ci
    |---|---|
    r0  r1  r2

Przesuni�cie ramki w prawo:

r0 = r1
r1 = r2
r2 = 0.5*r1 + 2*r0
*/

float seq1(int n) {
	float r0 = 3;
	float r1 = 4;
	float r2 = 8;
	
	if (n == 1) return r0;
	if (n == 2) return r1;
	if (n == 3) return r2;
	
	int i;
	for (i = 1; i <= n-3; i++){
		r0 = r1;
		r1 = r2;
		r2 = 0.5*r1 + 2*r0;
	}
	
	return r2;
}

/*
- ile razy nale�y przesun�� ramk� w prawo, 
aby wyznaczy� warto�� n-tego wyrazu ci�gu 
w funkcji seq dla n >= 3 ?

odp.:Nale�y przesun�� o n-3

- dokonaj analizy wywo�ania seq1(4).

* seq1(4) = 12
  n = 4 - 1 = 3
  r0 = 3
  r1 = 4
  r2 = 8
  
  4 == 1  false
  4 == 2  false
  4 == 3  false
  
  i
  
  i = 1
  1 <= 1   r0 = 4
  		   r1 = 8
  		   r2 = 0.5*8 + 2*4 = 12   i = 2
  
  2 <= 1   false
  
  return r2 = 12

- narysuj graf oblicze� dla seq1(4).

s(1)  s(2)    s(3)
         \      |
 	 	2*s(2)	0.5*s(3)        
		    \   |
             \  |
              s(4)
*/

float seq2(int n) {
	float r0 = 3;
	float r1 = 4;
	
	if (n == 1) return r0;
	if (n == 2) return r1;
	
	int i;
	for (i = 1; i <= n-2; i++){
		int pom = r0;
		r0 = r1;
		r1 =  0.5*r1 + 2*pom;
	}
	
	return r1;
}
/*
- ile razy nale�y przesun�� ramk� w prawo, aby wyznaczy� warto�� n-tego wyrazu ci�gu w funkcji seq2 dla n >= 2 ?

odp.:Nale�y przesun�� o n-2



- dokonaj analizy wywo�ania seq2(4).

* seq1(4) = 12
  r0 = 3
  r1 = 4
  r2 = 8
  
  4 == 1  false
  4 == 2  false
  
  i
  
  i = 1
  1 <= 2   pom = 3
  		   r0 = 4
  		   r1 = 0.5*4 + 2*3 = 2 + 6 = 8  i = 2

  2 <= 2   pom = 4
  		   r0 = 8
  		   r1 = 0.5*8 + 2*4 = 4 + 8 = 12  i = 3
  
  3 <= 2   false
  
  return r1 = 12

- narysuj graf oblicze� dla seq1(4).

s(1)  s(2)    s(3)
         \      |
 	 	2*s(2)	0.5*s(3)        
		    \   |
             \  |
              s(4)
*/

float seq3(int n) {
  if (n == 1) {
    return 3;
  } else if (n == 2) {
    return 4;
  } else {
    return 0.5*seq3(n - 1) + 2*seq3(n - 2);
  }
}

int main() {
	printf("sequence.c\n\n");
	int n;
	printf("Podaj n-ty wyraz ciagu = ");
	scanf("%u",&n);

	printf("seq3(%u) = %g\n", n, seq3(n));
	
	return 0;
}


