#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("endian2.c\n\n");
    
    int i = 1;
    char *c = (char*)&i;
    if (*c) printf("little-endian architecture\n");
	else printf("big-endian architecture\n");
    
    return 0;
}
